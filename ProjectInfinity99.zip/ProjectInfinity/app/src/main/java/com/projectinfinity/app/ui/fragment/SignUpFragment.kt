import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.fragment.app.Fragment
import androidx.fragment.app.add
import androidx.fragment.app.commit
import com.projectinfinity.app.R
import com.projectinfinity.app.ui.activity.DashboardActivity
import com.projectinfinity.app.utils.Constants.KEY_EMAIL
import com.projectinfinity.app.utils.GeneralUtils.displayToast
import com.projectinfinity.app.utils.GeneralUtils.isEmailValid
import com.projectinfinity.app.utils.GeneralUtils.isPhoneNumberValid
import kotlinx.android.synthetic.main.fragment_sign_up.*


class SignUpFragment : Fragment(R.layout.fragment_sign_up) {
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        btn_sign_up_sign_up_fragment.setOnClickListener {
            //accessing data from edit text
            val firstName = et_first_name.text.toString()
            val lastName = et_last_name.text.toString()
            val phoneNumber = et_phone_number.text.toString()
            val occupation = et_occupation.text.toString()
            val companyName = et_company_name.text.toString()
            val email = et_email_sign_up.text.toString()
            if (isInputDataValid(
                    firstName,
                    lastName,
                    phoneNumber,
                    companyName,
                    occupation,
                    email
                )
            ) {
                requireActivity().supportFragmentManager.commit {
                    //Passing email to DashboardActivity with the help of intent
                    val signUpIntent =
                        Intent(requireContext(), DashboardActivity::class.java).putExtra(
                            KEY_EMAIL,
                            email
                        )
                    startActivity(signUpIntent)
                    addToBackStack(SignUpFragment::class.java.name)
                }
            }
        }
        //If you click on Sign up then you will go to SignUpFragment
        tv_sign_in_sign_up_fragment.setOnClickListener {
            requireActivity().supportFragmentManager.commit {
                setReorderingAllowed(true)
                add<SignInFragment>(R.id.fcv_activity_launcher)
                addToBackStack(SignInFragment::class.java.name)
            }
        }
    }

    //Details validation function
    private fun isInputDataValid(
        firstName: String,
        lastName: String,
        phoneNumber: String,
        companyName: String,
        occupation: String,
        email: String,
    ): Boolean {
        if (firstName.isEmpty()) {
            requireContext().displayToast(getString(R.string.Please_First_Name))
            return false
        } else if (lastName.isEmpty()) {
            requireContext().displayToast(getString(R.string.Please_Enter_Last_Name))
            return false
        } else if (phoneNumber.isEmpty()) {
            requireContext().displayToast(getString(R.string.Please_Enter_Phone_Number))
            return false

        } else if (phoneNumber.isPhoneNumberValid()) {
            requireContext().displayToast(getString(R.string.Please_Enter_Valid_Phone_Number))
            return false

        } else if (email.isEmpty()) {
            requireContext().displayToast(getString(R.string.Please_Enter_Your_Email))
            return false

        } else if (!email.isEmailValid()) {
            requireContext().displayToast(getString(R.string.Please_Enter_Valid_Email))
            return false

        } else if (occupation.isEmpty()) {
            requireContext().displayToast(getString(R.string.Please_Enter_Occupation))
            return false

        } else if (companyName.isEmpty()) {
            requireContext().displayToast(getString(R.string.Please_Enter_Valid_Occupation))
            return false

        } else {
            return true
        }
    }

}