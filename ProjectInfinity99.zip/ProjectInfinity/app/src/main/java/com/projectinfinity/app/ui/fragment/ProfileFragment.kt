package com.projectinfinity.app.ui.fragment

import android.os.Bundle
import android.view.*
import androidx.fragment.app.Fragment
import com.projectinfinity.app.R
import com.projectinfinity.app.utils.Constants
import com.projectinfinity.app.utils.Constants.KEY_EMAIL
import com.projectinfinity.app.utils.GeneralUtils.displayToast
import com.projectinfinity.app.utils.SharedPreferenceManager
import kotlinx.android.synthetic.main.activity_dashboard.*
import kotlinx.android.synthetic.main.fragment_profile.*

class ProfileFragment : Fragment(R.layout.fragment_profile) {
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setHasOptionsMenu(true)
        val email = arguments?.getString(KEY_EMAIL)
        tv_email_profile_fragment.text = email
    }

    //This function will inflate menu_item
    override fun onCreateOptionsMenu(menu: Menu, inflater: MenuInflater) {
        menu.clear()
        inflater.inflate(R.menu.profile_menu_items, menu)
        //sets the toolbar title
        requireActivity().toolbar_dashboard?.title ="Profile"

    }

    //This function will help to select the menu_item
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.profile_menu_dashboard -> {
                requireActivity().supportFragmentManager.popBackStack()
                true
            }
            R.id.profile_menu_logout -> {
                SharedPreferenceManager.clearPreference()
                requireActivity().finish()
                true
            }

            else -> {
                false
            }
        }
    }



}