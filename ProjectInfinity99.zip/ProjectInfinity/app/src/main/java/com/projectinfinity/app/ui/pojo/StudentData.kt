package com.projectinfinity.app.ui.pojo

data class StudentData(
    val name:String,
    val dob:String,
    val division:String,
    val rollNo:String,
    val image:String


    )
