package com.projectinfinity.app.utils

import android.content.Context
import android.widget.Toast
import java.util.regex.Matcher
import java.util.regex.Pattern

object GeneralUtils {
    /**
     * Method to check email
     * is valid or not
     * true if valid
     * false if not valid
     */
    fun String.isEmailValid(): Boolean {
        val pattern: Pattern
        val matcher: Matcher
        val EMAIL_PATTERN =
            "^[_A-Za-z0-9-]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$"
        pattern = Pattern.compile(EMAIL_PATTERN)
        matcher = pattern.matcher(this)
        return matcher.matches()
    }

    /**
     * Method to check password length
     * is valid or not
     * true if valid
     * false if not valid
     */
    fun String.isPasswordValid(): Boolean {
        return this.length >= 3
    }
    fun String.isPhoneNumberValid(): Boolean {
        return this.length !=10
    }

    /**
     * Method to show toast of [text]
     */
    fun Context.displayToast(text: String) {
        Toast.makeText(this, text, Toast.LENGTH_SHORT).show()
    }
}