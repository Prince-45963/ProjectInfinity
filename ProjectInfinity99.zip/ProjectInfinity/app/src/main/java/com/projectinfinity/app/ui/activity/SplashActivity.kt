package com.projectinfinity.app.ui.activity

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import androidx.appcompat.app.AppCompatActivity
import com.projectinfinity.app.R
import com.projectinfinity.app.utils.Constants.SPLASH_SCREEN_TIME_OUT
import com.projectinfinity.app.utils.SharedPreferenceManager


class SplashActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash)

        Handler().postDelayed(Runnable {
            SharedPreferenceManager.initPref(this)
            if(SharedPreferenceManager.idPref!=0){
                val intent = Intent(this, DashboardActivity::class.java)
                startActivity(intent)
                finish()
            } else {
                val launcherIntent = Intent(this, LauncherActivity::class.java)
                //Intent is used to switch from one activity to another.
                startActivity(launcherIntent)
                finish()

            }
            //invoke the launcherIntent.

            //the current activity will get finished.
        }, SPLASH_SCREEN_TIME_OUT)
    }
}