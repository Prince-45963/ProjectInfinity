package com.projectinfinity.app.ui.activity

import android.content.Intent
import android.os.Bundle
import android.view.Menu
import android.view.MenuInflater
import android.view.MenuItem
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContentProviderCompat.requireContext
import androidx.core.os.bundleOf
import androidx.fragment.app.add
import androidx.fragment.app.commit
import com.projectinfinity.app.R
import com.projectinfinity.app.ui.fragment.ProfileFragment
import com.projectinfinity.app.ui.fragment.WelcomeFragment
import com.projectinfinity.app.utils.Constants.KEY_EMAIL
import com.projectinfinity.app.utils.Constants.KEY_FIRST_NAME
import com.projectinfinity.app.utils.Constants.MESSAGE_LOGOUT
import com.projectinfinity.app.utils.Constants.MESSAGE_PROFILE
import com.projectinfinity.app.utils.Constants.MESSAGE_SETTING
import com.projectinfinity.app.utils.GeneralUtils.displayToast
import com.projectinfinity.app.utils.SharedPreferenceManager

import kotlinx.android.synthetic.main.activity_dashboard.*


class DashboardActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_dashboard)
        setSupportActionBar(toolbar_dashboard)


        //accessing intent value
        val firstName = intent.getStringExtra(KEY_FIRST_NAME)
        val email = intent.getStringExtra(KEY_EMAIL)


            supportFragmentManager.commit {
                setReorderingAllowed(true)
                //send bundle to welcome fragment
                val detailBundle = bundleOf(KEY_FIRST_NAME to firstName, KEY_EMAIL to email)
                add<WelcomeFragment>(R.id.fcv_activity_dashboard, args = detailBundle)
            }
        }



    //This function will inflate menu_item
    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        val inflater: MenuInflater = menuInflater
        inflater.inflate(R.menu.menu, menu)
        //sets the toolbar title
        toolbar_dashboard.title = "Dashboard"
        return true

    }

    //This function will help to select the menu_item
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.menu_profile -> {
                val email = intent.getStringExtra(KEY_EMAIL)
                supportFragmentManager.commit {
                    setReorderingAllowed(true)
                    val bundle = bundleOf(KEY_EMAIL to email)
                    add<ProfileFragment>(R.id.fcv_activity_dashboard, args = bundle)
                    addToBackStack(ProfileFragment::class.java.name)
                }
                true
            }
            R.id.menu_logout -> {
                SharedPreferenceManager.clearPreference()
                finish()

                true
            }

            else -> {
                false
            }
        }
    }

}

