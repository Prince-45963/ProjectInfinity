package com.projectinfinity.app.utils

import android.content.Context
import android.content.SharedPreferences
import com.projectinfinity.app.utils.SharedPreferenceManager.KEY_TOKEN

object SharedPreferenceManager {
    const val SHARED_PREFERENCES_KEY="shared_preferences_key"
     var EMAIL="email"
    const val KEY_TOKEN="key_token"
    const val KEY_ID="key_id"

    const val PASSWORD="password"
    private var sharePre: SharedPreferences?=null
    fun initPref(context: Context){
        if(sharePre==null){
            sharePre=context.getSharedPreferences(SHARED_PREFERENCES_KEY,Context.MODE_PRIVATE)
        }
    }

    fun clearPreference()= sharePre!!.edit()?.putInt(KEY_ID,0)?.apply()


    var tokenPref:String?
        get()= sharePre?.getString(KEY_TOKEN,"")
        set(tokenPref)= sharePre?.edit()?.putString(KEY_TOKEN,tokenPref!!)!!.apply()
    var idPref:Int?
        get()= sharePre?.getInt(KEY_ID,0)
        set(idPref)= sharePre?.edit()?.putInt(KEY_ID,idPref!!)!!.apply()
    var email: String?
       get()=sharePre?.getString(EMAIL,"")

       set(email)= sharePre?.edit()?.putString(EMAIL,email)!!.apply()
    }

